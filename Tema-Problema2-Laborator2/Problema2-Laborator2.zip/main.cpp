#include "studenti.h"
#include <iostream>

using namespace std;

int main() {

	int numar_studenti = 2;

	citire_date_student(numar_studenti);

	afisare_date_student(numar_studenti);

}

		


